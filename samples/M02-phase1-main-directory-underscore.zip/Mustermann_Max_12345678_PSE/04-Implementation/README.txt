Implementation starts in phase 2.
